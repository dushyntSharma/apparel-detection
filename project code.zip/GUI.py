import sys
import os
from tkinter import *
from PIL import ImageTk,Image
import tkinter.font as font
from tkinter import messagebox
import random

window=Tk(className="Fashion Apparel")
frame = Frame(window) 
frame.pack() 

FILENAME='img.jpg'

#set width and height
myFont = font.Font(family='Courier', size=20, weight='bold')
canvas=Canvas(window,width=1920,height=1080)
canvas.pack()
tk_img = ImageTk.PhotoImage(file = FILENAME)
canvas.create_image(800,510,image=tk_img)


fa = Label(window,text = "FASHION APPAREL DETECTION SYSTEM",font = "GAZZARELLI 30 bold").place(x = 200, 
                                           y = 200)    

quit_button = Button(window, text = "Quit", command = window.destroy, anchor = 'c',
                    width = 15, activebackground = "#33B5E5")
quit_button.place(relx = 0.5, x =200, y =550, anchor = CENTER)

window.geometry('1920x1080')

def runclassify1():
    messagebox.showinfo("Message", "Please wait, we are loading the software.")
    os.system('CaptureImage.py')
def runclassify():
    messagebox.showinfo("Message", "Please wait, we are loading the software.")
    os.system('LiveVideo.py')
def runimport():
    messagebox.showinfo("Message", "Please wait, we are loading the software.")
    os.system('importimage.py')
def cdataset():
    messagebox.showinfo("Message", "Please wait, we are loading the software.")
    os.system('search_bing_api.py')
    sys.exit()
def trainm():
    con=messagebox.askokcancel("Confirm", "Training the Model will take time(approx. 90min).")
    if(con==True):
        os.system('train.py')
    else:
        return

capimg = Button(window, text = "Click Picture", command = runclassify1, anchor = 'c',
                    width = 15, activebackground = "#33B5E5")
capimg.place(relx = 0.5, x =200, y = 350, anchor = CENTER)


liveimg = Button(window, text = "Live Video", command = runclassify, anchor = 'c',
                    width = 15, activebackground = "#33B5E5")
liveimg.place(relx = 0.5, x =-220, y = 350, anchor =CENTER )

impimg = Button(window, text = "Select Image", command = runimport, anchor = 'c',
                    width = 15, activebackground = "#33B5E5")
impimg.place(relx = 0.5, x =-220, y = 450, anchor =CENTER )

dataset = Button(window, text = "Create Dataset", command = cdataset, anchor = 'c',
                    width = 15, activebackground = "#33B5E5")
dataset.place(relx = 0.5, x =200, y = 450, anchor =CENTER )

train = Button(window, text = "Train Model", command = trainm, anchor = 'c',
                    width = 15, activebackground = "#33B5E5")
train.place(relx = 0.5, x =-220, y = 550, anchor =CENTER )


train['font']=myFont
quit_button['font'] = myFont
capimg['font'] = myFont
liveimg['font'] = myFont
impimg['font'] = myFont
dataset['font']=myFont

window.mainloop()
